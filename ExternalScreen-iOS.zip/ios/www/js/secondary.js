
// If using Cordova in External Screen, use 'deviceready' event:
//document.addEventListener('deviceready', function () {
	
	// Display Screen Dimensions
	var dim = window.innerWidth+' x '+window.innerHeight;
	document.getElementById('dimensions').innerHTML = 'Dimensions: '+dim;
	
	// Save dimensions to localStorage to access in index.html
	localStorage.ExternalScreenDimensions = dim;
	
	// Update Text area (from ExternalScreen.invokeJavaScript())
	function updateText(value) {
		document.getElementById('textbox').innerHTML = value;
	}
	
//}, false); //-- 'deviceready' event