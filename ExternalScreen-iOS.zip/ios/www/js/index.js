document.addEventListener('deviceready', function () {
	
	// As user types, change text on External Screen
	document.getElementById('text').oninput = function () {
		ExternalScreen.invokeJavaScript('updateText("'+this.value+'")');
	};
	
	// Is External Screen currently connected?
	var connected = false;
	// Check for External Screen availability every second and update user UI if status changes. (.checkAvailability() does NOT have to be called before initiating .loadHTML() and .invokeJavaScript() methods. They will simply fail if no external screen is present.)
	var int = setInterval(function () {
		
		ExternalScreen.checkAvailability(function (isAvailable) {
			
			if (isAvailable) {
				
				if (!connected) { // If External Screen is not currently connected...
					connected = true;
					// Open page on external screen
					ExternalScreen.loadHTML('secondary.html', function () {
						// Invoke JS
						setTimeout(function () {
							var val = document.getElementById('text').value;
							ExternalScreen.invokeJavaScript('updateText("'+val+'")');
						}, 1000)
					});
				}
				// Check if External Screen Dimensions set in localStorage by secondary.js
				var dim = (localStorage.ExternalScreenDimensions)? localStorage.ExternalScreenDimensions: 'Connected';
				document.getElementById('status').innerHTML = 'External Screen: '+dim;
				document.getElementById('status').className = 'connected';
				
			} else {
				if (connected) {
					connected = false; // Reset Connection status
				}
				document.getElementById('status').innerHTML = 'No External Screen Connected';
				document.getElementById('status').className = '';
			}
			
		});
		
	}, 1000);
	
}, false);